package demo.seltest1;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class App 
{
    public static void main( String[] args )
    {
    	try{
    		System.setProperty("webdriver.chrome.driver", "D:\\DemoSelenium\\chromedriver.exe");
    		
    		WebDriver driver = new ChromeDriver();
    		driver.get("D:\\DemoSelenium\\webpages\\CheckBoxTest.html");
    		
    		WebElement checkbox = driver.findElement(By.id("lettuceCheckbox"));
    		/*Thread.sleep(2000);*/
    		checkbox.click();
    		
    		if(checkbox.isSelected()){
    			System.out.println("Value of checkbox :-" +checkbox.getAttribute("value"));
    		}
   /* 		WebElement searchField = driver.findElement(By.id("lst-ib"));
    		searchField.sendKeys("capgemini");
    		searchField.submit();
    		
    		WebElement imagesLink = driver.findElements(By.linkText("Images")).get(0);
    		imagesLink.click();
    		
    		WebElement imageElement = driver.findElements(By.cssSelector("a[class = rg_l]")).get(3);
    		
    		WebElement imageLink = imageElement.findElements(By.tagName("img")).get(0);
    		imageLink.click();*/
    		
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }
}
