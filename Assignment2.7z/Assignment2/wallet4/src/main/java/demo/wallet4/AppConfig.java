package demo.wallet4;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


import demo.beans.Customer;
import demo.repo.RepoImpl;
import demo.service.ServiceImpl;
@Configuration
@ComponentScan(basePackages ="demo.")
public class AppConfig {

	@Bean(value="map")
	public Map<String,Customer> getMap(){
		return new HashMap<String,Customer>();
	}
	@Bean(value="repo")
	public  demo.repo.WalletRepo getRepo(){
		return new demo.repo.RepoImpl(getMap());
		//return null;
	}
	@Bean(value="service")
	public demo.service.WalletService getService() {
		return new demo.service.ServiceImpl(getRepo());
	}


}
