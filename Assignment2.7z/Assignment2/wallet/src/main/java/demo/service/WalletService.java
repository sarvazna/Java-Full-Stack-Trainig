package demo.service;

import demo.beans.Customer;
import demo.beans.Wallet;

public interface WalletService {
	public  Customer createAccount(int id, String name,String mobileNumber,Wallet wallet);
	public  Customer showBalance(int id);
	public Customer depositAmount(int id, float depositAmount);
	public Customer withDrawAmount(int id, float withDrawAmount);

}
