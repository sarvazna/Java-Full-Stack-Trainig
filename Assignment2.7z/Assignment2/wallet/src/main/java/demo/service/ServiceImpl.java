package demo.service;

import javax.persistence.EntityManager;

import demo.beans.Customer;
import demo.beans.Wallet;
import demo.repo.WalletRepo;
//import demojpa.eaktoeak.Employee;


public class ServiceImpl implements WalletService {
	private WalletRepo repo;
	protected EntityManager em;
	/*public ServiceImpl(EntityManager em) {
		super();
		this.em = em;
	}*/
	public ServiceImpl(WalletRepo repo, EntityManager em) {
		super();
		this.repo = repo;
		this.em = em;
	}
	public Customer createAccount(int id, String name, String mobileNumber, Wallet wallet) {
		Customer customer=new Customer(id);
		//Wallet wallet=new Wallet();
		customer.setName(name);
		customer.setMobileNumber(mobileNumber);
		//wallet.setBalance(amount);
		customer.setWallet(wallet);
		em.persist(customer);
		//repo.save(customer);
		return customer;
	}
	

	


	public ServiceImpl(WalletRepo repo) {
		//super();
		this.repo = repo;
	}



	public ServiceImpl() {
		// TODO Auto-generated constructor stub
	}


	/*public Customer showBalance(String mobileNumber) {

		return repo.findOne(mobileNumber);
	}*/


	public Customer depositAmount(int id, float depositAmount) {
		// TODO Auto-generated method stub
		Customer customer = repo.findOne(id);
		Wallet wallet = em.find(Wallet.class, id);
		//Wallet wallet = customer.getWallet();
		float amount = wallet.getBalance() + depositAmount;
		wallet.setBalance(amount);
		customer.setWallet(wallet);
		em.persist(customer);
		return customer;
	}


	public Customer withDrawAmount(int id, float withDrawAmount) {
		// TODO Auto-generated method stub
		Customer customer = repo.findOne(id);
		Wallet wallet = em.find(Wallet.class, id);
		float amount = wallet.getBalance() - withDrawAmount;
		wallet.setBalance(amount);
		customer.setWallet(wallet);
		//repo.save(customer);
		em.persist(customer);
		return customer;
	}
	/*@Override
	public Customer createAccount(String name, String mobileNumber, float amount) {
		// TODO Auto-generated method stub
		return null;
	}*/
	public Customer showBalance(int id) {
		// TODO Auto-generated method stub
		return em.find(Customer.class, id);
	}
	
	

}
