package demo.repo;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import demo.beans.Customer;
@Repository
public class RepoImpl implements WalletRepo{
	
//@Resource(name = "data")
	private Map<String,Customer> data;
	public RepoImpl(Map<String, Customer> data2) {
		// TODO Auto-generated constructor stub
	data=data2;
	}


	public boolean save(Customer c) {
		data.put(c.getMobileNumber(),c);
		
		return true;
	}


	public Customer findOne(String mobileNumber) {
		
		return data.get(mobileNumber);
	}

	
	
	

}
