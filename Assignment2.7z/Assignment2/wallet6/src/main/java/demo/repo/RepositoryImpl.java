package demo.repo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;


import demo.beans.Customer;
import demo.beans.Wallet;

public class RepositoryImpl implements WalletRepo{
	Map<String,Customer> data;

	public RepositoryImpl(Map<String, Customer> data) {
		this.data=data;
	}

	@Override
	public boolean save(Customer c) {

		int wallet_id=0;
		float balance= c.getWallet().getBalance();
		String name=c.getName();
		String mobileNumber=c.getMobileNumber();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test");  
			Statement stmt=con.createStatement();  
			stmt.executeUpdate("insert into wallet(balance) values("+balance+")"); 
			ResultSet rs=stmt.executeQuery("select wallet_id from wallet where balance="+balance+"");
			while(rs.next())
				wallet_id=rs.getInt("wallet_id");
			stmt.executeUpdate("insert into Customer(name,mobileNumber,wallet_id) values('"+name+"','"+mobileNumber+"',"+wallet_id+")");
			System.out.println("Customer is created");

			con.close(); 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return true;
	}

	@Override
	public Customer findOne(String mobileNumber) {

		Customer customer=new Customer(); 
		Wallet wallet=new Wallet();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test");  
			Statement stmt=con.createStatement();


			ResultSet rs=stmt.executeQuery("select customer.name,customer.mobileNumber,wallet.balance from customer INNER JOIN wallet ON wallet.wallet_id=customer.wallet_id where mobilenumber='"+mobileNumber+"'");

			while(rs.next())
			{
				Float balance=rs.getFloat("balance");
				String name1 = rs.getString("name");
				String mobileNumber1=rs.getString("mobileNumber");
				customer.setName(name1);
				customer.setMobileNumber(mobileNumber1);
				wallet.setBalance(balance);
				customer.setWallet(wallet);
			}

			con.close();


		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return customer;
	}

	@Override
	public boolean update(Customer c) {
			float balance= c.getWallet().getBalance();
			String mobileNumber=c.getMobileNumber();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test");  
				
			String sql="update customer inner join wallet on wallet.wallet_id=customer.wallet_id set wallet.balance =? where mobileNumber=?";
			java.sql.PreparedStatement stmt=con.prepareStatement(sql);
			stmt.setDouble(1,balance);
			stmt.setString(2, mobileNumber);			
			stmt.executeUpdate();
	
				//con.close();


			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return true;

		}

	}

	


