package com.cg.WalletSpringboot;

import java.sql.SQLException;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

//import demo.Many2One_SDData.Employee;
//import demo.beans.Customer;

public interface WalletRepoInterface extends JpaRepository<Customer,Integer> {
	
	
	@Query(value="Select c from Customer c JOIN FETCH c.wallet where c.mobileNumber = ?1")
	public Customer findOne(String mobileNumber);
  
}
