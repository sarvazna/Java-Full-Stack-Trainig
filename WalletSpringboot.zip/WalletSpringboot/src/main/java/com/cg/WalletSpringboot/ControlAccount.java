package com.cg.WalletSpringboot;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
@Controller

@ComponentScan
	
public class ControlAccount {
	@Autowired
	WalletServiceInterface service;
	
		@RequestMapping(value="/createAccount", method=RequestMethod.POST)
		
		public @ResponseBody  Customer createAccount(Customer c) throws ClassNotFoundException, SQLException {
			
		  Customer c1 = service.createAccount(c);
			return c1;
			
		 }
		
       @RequestMapping(value="/showAccount", method=RequestMethod.POST)
		
		public @ResponseBody  Customer showBalance(String mobileNumber) {
    	   Customer c2= service.showBalance(mobileNumber);
			return c2;
	
	
    }
}
