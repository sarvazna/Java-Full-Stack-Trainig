package com.cg.WalletSpringboot;

//package demo.Base_App_SPData;

import java.sql.SQLException;

//import demo.beans.Customer;
//import demo.beans.Wallet;

public interface WalletServiceInterface {
	public Customer createAccount(Customer c) throws ClassNotFoundException, SQLException;
	public Customer showBalance(String mobileNumber);
    public boolean withdraw(String mobileNumber,float amount);
    public boolean deposit(String mobileNumber,float amount);
}
