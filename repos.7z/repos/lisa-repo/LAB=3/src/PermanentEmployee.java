
public class PermanentEmployee extends Employee{
	public static int count;
	public String name;
	public double salary;
	public Date doj;
	
	public PermanentEmployee(String name,double salary,Date doj){
		super(name,salary);
		this.doj=doj;
	count=count+1;	
	}
	public void displaypermanent(){
		 System.out.println("--------------------------------------------------");
		System.out.println( "Employee Name :"+getName()+ " \n Salary is :"+getSalary()+ "\nDoj: "+doj);
	     System.out.println("--------------------------------------------------");
	
	}
}

