public class Entry {
public static void main(String[] args) {
	Date d=null;
	d=new Date(22,11,2017);
	Employee e = new Employee("Ram",20000.00);
	PermanentEmployee p=null;
	 d=new Date(16,10,2017); 
	 p = new PermanentEmployee("Suresh",30000,d);
	 p.displaypermanent();
	 d=new Date(13,10,2017); 
     p = new PermanentEmployee("Naresh",25000,d);
     p.displaypermanent();
     d=new Date(02,10,2017); 
	p = new PermanentEmployee("Mahesh",15000,d);
	p.displaypermanent();

	System.out.println("Total No of Permanent Employees : "+PermanentEmployee.count);
	System.out.println("********************************************");
	ContractEmployee c=null;
	Contractor con=null;
	d=new Date(22,10,2016);
	c = new ContractEmployee(6,d);	
	con = new Contractor("Ramesh",10000);
	c.setContractor(con);
	con.displayContract();
	c.displayContract();
	d=new Date(11,10,2017);
	c = new ContractEmployee(4,d);
	con = new Contractor("vinay",10000);
	c.setContractor(con);
	con.displayContract();
	c.displayContract();
	System.out.println("Total No of Contract Employees : "+ContractEmployee.count);
	System.out.println("*************************************************");
	
	
}


}

