import java.util.Comparator;
import java.util.Set;
import java.util.TreeMap;

import com.cg.Product;
import com.cg.ProductPK;

public class Entry1 {
public static void main(String[] args) {
	TreeMap<ProductPK, Product> entries = new TreeMap<>(new ProductPKComparator());
	
	Product value1 = new Product(100,"Car",1000.0d);
	ProductPK key1 = new ProductPK(value1.getId(), value1.getPrice());
	entries.put(key1, value1);
	//System.out.print(entries);
	
	Product value2 = new Product(102,"Bike",500.0d);
	ProductPK key2 = new ProductPK(value2.getId(), value2.getPrice());
	entries.put(key2, value2);
	
	Product value3 = new Product(103,"Bicycle",100.0d);
	ProductPK key3 = new ProductPK(value3.getId(), value3.getPrice());
	entries.put(key3, value3);
	
	Product value4 = new Product(104,"Auto",150.0d);
	ProductPK key4 = new ProductPK(value4.getId(), value4.getPrice());
	entries.put(key4, value4);
	
	Product value5 = new Product(101,"Toy",10.0d);
	ProductPK key5 = new ProductPK(value5.getId(), value5.getPrice());
	entries.put(key5, value5);
	
	System.out.println(entries.size());
	
	Set<ProductPK> keys =  entries.keySet();
	
	
	for(ProductPK key :  keys)
		System.out.println(key);
	
}
}

class ProductPKComparator implements Comparator<ProductPK>{
	//Product products;
	public int compare(ProductPK o1, ProductPK o2) {
		// TODO Auto-generated method stub
//		return 0;
		
		int diff = o1.getPrice().compareTo(o2.getPrice());
		//int diff1 = o1.getPrice().compareTo(o2.getPrice());
		if(diff != 0)
			return diff;
		else{
			diff = o1.getId() - o2.getId();
			return diff;
		}
		
		
	}
	
	
}