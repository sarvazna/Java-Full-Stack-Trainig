
public class Person 
{
	public String userName;
	public int age;
	public Person()
	{
		this.userName = null;
		 this.age = 0;
	}
	public Person(String uname, int age)
	{
		 this.userName = uname;
		 this.age = age;
	}
	public boolean equals(Object obj)
	{
		if(this.userName.equals(((Person)obj).userName))
		{
			System.out.println("equals");
			return true;
		}
		else
				return false;
	}
	
}
