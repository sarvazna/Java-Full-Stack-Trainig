
public class Entry 
{

	 //Person p = null;
	public static void main(String[] args)
	{
		 Person p = null;
    	new Person();
	
		Person p1 = new Person("vikas",18);
		Person p2 = new Person("vikas",20);
		p.equals(p2);
	}
}