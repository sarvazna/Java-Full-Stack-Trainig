package example;


import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.*;


public class EmployeeTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		
		EntityManager em = emf.createEntityManager();
          Calendar cal1 = new GregorianCalendar();
          Calendar cal2 = new GregorianCalendar(); 
          Calendar cal3 = new GregorianCalendar();
	   
		
		cal1.set(1975,7,3);
		cal2.set(1996,10,28);
		cal3.set(1997,02,14);
		EmployeeService service = new EmployeeService(em);
		em.getTransaction().begin();
		Address add1 = new Address(50948,"Talwade");
		Address add2 = new Address(50900,"DEhu");
		Address add3 = new Address(50905,"DEhu");
		Department dept1 = service.createDepartment(1, "it");
		Department dept2 = service.createDepartment(2, "testing");
		
		Employee emp = service.createEmployee(50948, "Sunki", 60000,add1,dept1,cal1,new Date(System.currentTimeMillis()));
		Employee emp2 =service.createEmployee(50949, "Rishi", 90000, add2,dept1,cal2,new Date(System.currentTimeMillis()));
		Employee emp3 = service.createEmployee(50950, "Mishi", 80000, add3,dept2,cal3,new Date(System.currentTimeMillis()));
		em.getTransaction().commit();
		System.out.println("Persisted "+emp);
		System.out.println("Persisted "+emp2);
		System.out.println("Persisted "+emp3);
		emp= service.findEmployee(50948);
		System.out.println("Found "+emp);
		
		em.getTransaction().begin();
		emp =service.raiseEmployeeSalary(50948, 20000);
		em.getTransaction().commit();
		System.out.println("Updated "+emp);
		
		em.getTransaction().begin();
		
		
		
		//Employee emp2 =service.createEmployee(50949, "Rishi", 90000, add2,dept1);
		//em.getTransaction().commit();
		
		/*List<Employee> emps = service.findAllEmployees();
		
		for(Employee e : emps){
			System.out.println("All employees :: "+e);
		}*/
		em.close();
		emf.close();
	}
}