package example;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class TestCalendar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Calendar cal = new GregorianCalendar();
	   
		
		cal.set(1975,7,3);
		cal.set(1996,10,28);
		cal.set(1997,02,14);
		String date = cal.get(Calendar.DATE)+"/"+cal.get(Calendar.MONTH)+"/"+cal.get(Calendar.YEAR);
		
		System.out.println(cal.get(Calendar.DATE)+"/"+cal.get(Calendar.MONTH)+"/"+cal.get(Calendar.YEAR));
	}

	
}
